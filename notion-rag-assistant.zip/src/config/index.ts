import dotenv from 'dotenv';
dotenv.config();

export const config = {
  port: Number(process.env.PORT) || 3000,
  notion: {
    apiKey: process.env.NOTION_API_KEY,
  },
  gemini: {
    apiKey: process.env.GEMINI_API_KEY,
  },
};

if (!config.notion.apiKey) {
  console.warn('Warning: NOTION_API_KEY is not set in environment variables.');
}

if (!config.gemini.apiKey) {
  console.warn('Warning: GEMINI_API_KEY is not set in environment variables.');
}
