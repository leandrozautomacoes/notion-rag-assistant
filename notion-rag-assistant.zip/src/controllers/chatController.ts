import { Request, Response } from 'express';
import { prepareChatContext } from '../services/chatService.ts';

export const handleChat = async (req: Request, res: Response) => {
  try {
    const { message } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    // Phase 1: Just retrieve context from Notion
    // In Phase 3, we might call Gemini here or return context to frontend
    const chatData = await prepareChatContext(message);

    res.json(chatData);
  } catch (error: any) {
    console.error('Chat controller error:', error);
    res.status(500).json({ error: error.message || 'Internal Server Error' });
  }
};
