import { searchNotion, NotionSource } from './notionService.ts';

export interface ChatResponse {
  context: string;
  sources: { title: string; url: string }[];
}

export const prepareChatContext = async (query: string): Promise<ChatResponse> => {
  const sources = await searchNotion(query);
  
  const context = sources
    .map((s) => `Source: ${s.title}\nContent: ${s.content}`)
    .join('\n\n');

  return {
    context,
    sources: sources.map((s) => ({ title: s.title, url: s.url })),
  };
};
