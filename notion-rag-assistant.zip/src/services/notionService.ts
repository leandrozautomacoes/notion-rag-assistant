import { Client } from '@notionhq/client';
import { config } from '../config/index.ts';

const notion = new Client({ auth: config.notion.apiKey });

export interface NotionSource {
  title: string;
  url: string;
  content: string;
}

export const searchNotion = async (query: string): Promise<NotionSource[]> => {
  if (!config.notion.apiKey) {
    throw new Error('Notion API key is missing');
  }

  try {
    // Search for pages matching the query
    const response = await notion.search({
      query,
      filter: {
        property: 'object',
        value: 'page',
      },
      page_size: 3,
    });

    const sources: NotionSource[] = [];

    for (const page of response.results) {
      if ('properties' in page) {
        // Extract title
        let title = 'Untitled';
        const titleProp = Object.values(page.properties).find(
          (prop) => prop.type === 'title'
        );
        if (titleProp && titleProp.type === 'title' && titleProp.title.length > 0) {
          title = titleProp.title[0].plain_text;
        }

        // Extract content from blocks
        const blocks = await notion.blocks.children.list({
          block_id: page.id,
        });

        const content = blocks.results
          .map((block: any) => {
            if (block.type === 'paragraph') {
              return block.paragraph.rich_text.map((t: any) => t.plain_text).join('');
            }
            if (block.type === 'bulleted_list_item') {
              return `- ${block.bulleted_list_item.rich_text.map((t: any) => t.plain_text).join('')}`;
            }
            if (block.type === 'numbered_list_item') {
              return `1. ${block.numbered_list_item.rich_text.map((t: any) => t.plain_text).join('')}`;
            }
            return '';
          })
          .filter((text) => text.length > 0)
          .join('\n');

        sources.push({
          title,
          url: (page as any).url,
          content,
        });
      }
    }

    return sources;
  } catch (error) {
    console.error('Error searching Notion:', error);
    throw error;
  }
};
