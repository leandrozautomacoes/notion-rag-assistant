import { useState, useRef, useEffect } from 'react';
import { Send, Terminal, Database, Cpu, Settings, Search, MessageSquare, BookOpen, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import ReactMarkdown from 'react-markdown';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  sources?: { title: string; url: string }[];
  isTyping?: boolean;
}

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const typeWriter = async (text: string, messageId: string) => {
    let currentText = '';
    const words = text.split(' ');
    
    for (let i = 0; i < words.length; i++) {
      currentText += (i === 0 ? '' : ' ') + words[i];
      setMessages((prev) => 
        prev.map((msg) => 
          msg.id === messageId ? { ...msg, content: currentText } : msg
        )
      );
      await new Promise(resolve => setTimeout(resolve, 30));
    }

    setMessages((prev) => 
      prev.map((msg) => 
        msg.id === messageId ? { ...msg, isTyping: false } : msg
      )
    );
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
    };

    setMessages((prev) => [...prev, userMessage]);
    const userQuery = input;
    setInput('');
    setIsLoading(true);

    try {
      // Step 1: Get context from Notion via Backend
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userQuery }),
      });

      if (!response.ok) throw new Error('Failed to fetch context');

      const data = await response.json();
      const context = data.context || "No relevant notes found.";
      
      // Step 2: Generate response with Gemini using the context
      const systemPrompt = `Você é o "Prompt Engineering Brain do Leandro".
Sua missão é atuar como um especialista em Engenharia de Prompts, focado em otimização estratégica.

REGRAS CRÍTICAS:
1. Responda BASEADO ESTRITAMENTE no contexto fornecido abaixo.
2. Se a resposta não estiver nas notas, diga exatamente: "Não encontrei esse assunto nas suas anotações de Prompt Engineering."
3. Use Markdown para listas, negrito e tópicos.
4. Mantenha um tom direto e estratégico.

CONTEXTO DO NOTION:
${context}`;

      const geminiResponse = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [{ role: 'user', parts: [{ text: userQuery }] }],
        config: {
          systemInstruction: systemPrompt,
          temperature: 0.2,
        }
      });

      const fullResponse = geminiResponse.text || "Não encontrei esse assunto nas suas anotações de Prompt Engineering.";
      
      const assistantMessageId = (Date.now() + 1).toString();
      const assistantMessage: Message = {
        id: assistantMessageId,
        role: 'assistant',
        content: '',
        sources: data.sources,
        isTyping: true,
      };

      setMessages((prev) => [...prev, assistantMessage]);
      await typeWriter(fullResponse, assistantMessageId);

    } catch (error) {
      console.error('Error:', error);
      const errorMessage: Message = {
        id: Date.now().toString(),
        role: 'assistant',
        content: "Ocorreu um erro ao processar sua solicitação. Verifique se as chaves de API estão configuradas corretamente.",
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-bg text-text-main font-sans">
      {/* Header */}
      <header className="h-[60px] bg-surface border-b border-border flex items-center justify-between px-6 shrink-0">
        <div className="flex items-center gap-3">
          <div className="bg-accent/10 p-1.5 rounded border border-accent/30">
            <Cpu className="w-5 h-5 text-accent" />
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-sm tracking-tight uppercase">NOTION RAG ASSISTANT</span>
            <span className="text-[10px] text-text-dim font-mono uppercase tracking-widest">Phase 3: Chat Interface & Logic</span>
          </div>
          <span className="ml-2 px-2 py-0.5 rounded border border-accent bg-accent/10 text-accent text-[10px] font-bold uppercase">
            v1.1.0
          </span>
        </div>
        <div className="flex items-center gap-6 text-[13px]">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-success shadow-[0_0_8px_rgba(63,185,80,0.5)]" />
            <span className="text-text-dim">Server: <span className="text-success font-medium">Running</span></span>
          </div>
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-text-dim" />
            <span className="text-text-dim">Env: <code className="bg-border/50 px-1.5 py-0.5 rounded text-xs font-mono">.env.production</code></span>
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-[260px] bg-surface border-r border-border p-5 flex flex-col gap-8 shrink-0">
          <section>
            <div className="text-[11px] font-bold text-text-dim uppercase tracking-wider mb-4 flex items-center gap-2">
              <Database className="w-3.5 h-3.5" />
              Project Structure
            </div>
            <div className="font-mono text-[13px] space-y-1.5">
              <div className="flex items-center gap-2 text-accent">
                <BookOpen className="w-4 h-4" />
                <span>src/</span>
              </div>
              <div className="pl-6 text-text-main/80 flex items-center gap-2">
                <Terminal className="w-3.5 h-3.5 opacity-50" />
                <span>server.ts</span>
              </div>
              <div className="pl-6 text-text-main/80 flex items-center gap-2">
                <Terminal className="w-3.5 h-3.5 opacity-50" />
                <span>routes.ts</span>
              </div>
              <div className="pl-6 text-accent/80 flex items-center gap-2">
                <BookOpen className="w-3.5 h-3.5 opacity-50" />
                <span>controllers/</span>
              </div>
              <div className="pl-6 text-accent/80 flex items-center gap-2">
                <BookOpen className="w-3.5 h-3.5 opacity-50" />
                <span>services/</span>
              </div>
            </div>
          </section>

          <section>
            <div className="text-[11px] font-bold text-text-dim uppercase tracking-wider mb-4 flex items-center gap-2">
              <Activity className="w-3.5 h-3.5" />
              Stack Health
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="text-text-dim">TypeScript</span>
                <span className="text-success font-mono">5.8.2</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-text-dim">Node.js</span>
                <span className="text-success font-mono">22.x</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-text-dim">Gemini API</span>
                <span className="text-success font-mono">3.0 Flash</span>
              </div>
            </div>
          </section>

          <div className="mt-auto pt-4 border-t border-border">
            <button className="w-full flex items-center gap-2 text-xs text-text-dim hover:text-text-main transition-colors">
              <Settings className="w-4 h-4" />
              Settings
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col bg-bg relative overflow-hidden">
          {/* Infinite Grid Background */}
          <div className="absolute inset-0 pointer-events-none opacity-[0.03]" 
               style={{ 
                 backgroundImage: `linear-gradient(var(--color-border) 1px, transparent 1px), linear-gradient(90deg, var(--color-border) 1px, transparent 1px)`,
                 backgroundSize: '40px 40px' 
               }} 
          />
          
          {/* Chat Area */}
          <div 
            ref={scrollRef}
            className="flex-1 overflow-y-auto p-8 space-y-6 scroll-smooth"
          >
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center max-w-2xl mx-auto space-y-6">
                <div className="w-16 h-16 bg-surface border border-border rounded-2xl flex items-center justify-center shadow-xl">
                  <Search className="w-8 h-8 text-accent" />
                </div>
                <div className="space-y-2">
                  <h2 className="text-xl font-bold tracking-tight">Prompt Engineering Brain</h2>
                  <p className="text-text-dim text-sm leading-relaxed">
                    Olá Leandro! Estou pronto para consultar suas notas de Engenharia de Prompt no Notion e gerar estratégias otimizadas.
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-3 w-full max-w-md">
                  {['Como estruturar um prompt?', 'Explique few-shot prompting', 'Melhores práticas para LLMs', 'Dicas de busca no Notion'].map((tip) => (
                    <button 
                      key={tip}
                      onClick={() => setInput(tip)}
                      className="p-3 text-left text-xs bg-surface border border-border rounded-lg hover:border-accent/50 hover:bg-accent/5 transition-all group"
                    >
                      <span className="text-text-dim group-hover:text-accent">{tip}</span>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="max-w-3xl mx-auto w-full space-y-8 pb-12">
                <AnimatePresence>
                  {messages.map((msg) => (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      key={msg.id}
                      className={`flex gap-4 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      {msg.role === 'assistant' && (
                        <div className="w-8 h-8 rounded bg-accent/10 border border-accent/20 flex items-center justify-center shrink-0">
                          <Cpu className="w-4 h-4 text-accent" />
                        </div>
                      )}
                      <div className={`max-w-[85%] space-y-3 ${msg.role === 'user' ? 'order-1' : 'order-2'}`}>
                        <div className={`p-4 rounded-xl text-sm leading-relaxed shadow-sm border ${
                          msg.role === 'user' 
                            ? 'bg-accent text-white border-accent' 
                            : 'bg-surface text-text-main border-border'
                        }`}>
                          {msg.role === 'assistant' ? (
                            <div className="prose prose-invert prose-sm max-w-none">
                              <ReactMarkdown>{msg.content}</ReactMarkdown>
                              {msg.isTyping && <span className="inline-block w-1.5 h-4 bg-accent ml-1 animate-pulse align-middle" />}
                            </div>
                          ) : (
                            msg.content
                          )}
                        </div>
                        
                        {msg.sources && msg.sources.length > 0 && !msg.isTyping && (
                          <motion.div 
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="space-y-2"
                          >
                            <div className="text-[10px] font-bold text-text-dim uppercase tracking-widest flex items-center gap-1.5">
                              <BookOpen className="w-3 h-3" />
                              Fontes do Notion
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {msg.sources.map((source, i) => (
                                <a
                                  key={i}
                                  href={source.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="px-2 py-1 bg-surface border border-border rounded text-[11px] text-accent hover:bg-accent/5 transition-colors flex items-center gap-1.5"
                                >
                                  <Search className="w-3 h-3" />
                                  {source.title}
                                </a>
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </div>
                      {msg.role === 'user' && (
                        <div className="w-8 h-8 rounded bg-border flex items-center justify-center shrink-0 order-2">
                          <Activity className="w-4 h-4 text-text-dim" />
                        </div>
                      )}
                    </motion.div>
                  ))}
                </AnimatePresence>
                {isLoading && (
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded bg-accent/10 border border-accent/20 flex items-center justify-center shrink-0 animate-pulse">
                      <Cpu className="w-4 h-4 text-accent" />
                    </div>
                    <div className="bg-surface border border-border p-4 rounded-xl flex items-center gap-2">
                      <div className="w-1.5 h-1.5 bg-accent rounded-full animate-bounce [animation-delay:-0.3s]" />
                      <div className="w-1.5 h-1.5 bg-accent rounded-full animate-bounce [animation-delay:-0.15s]" />
                      <div className="w-1.5 h-1.5 bg-accent rounded-full animate-bounce" />
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="p-6 bg-gradient-to-t from-bg via-bg to-transparent">
            <div className="max-w-3xl mx-auto relative">
              <div className="absolute inset-0 bg-accent/5 blur-xl rounded-full opacity-50" />
              <div className="relative bg-surface border border-border rounded-2xl p-2 flex items-center gap-2 shadow-2xl focus-within:border-accent/50 transition-all">
                <div className="pl-3">
                  <MessageSquare className="w-5 h-5 text-text-dim" />
                </div>
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Pergunte sobre suas notas de engenharia de prompt..."
                  className="flex-1 bg-transparent border-none focus:ring-0 text-sm py-3 px-2 placeholder:text-text-dim/50"
                />
                <button
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading}
                  className="bg-accent hover:bg-accent/90 disabled:opacity-50 disabled:cursor-not-allowed text-white p-2.5 rounded-xl transition-all shadow-lg shadow-accent/20"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
              <div className="mt-3 text-[10px] text-center text-text-dim font-mono uppercase tracking-widest">
                Retrieval-Augmented Generation Engine • Notion + Gemini 3.0 Flash
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
