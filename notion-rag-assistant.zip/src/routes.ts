import { Router } from 'express';
import { handleChat } from './controllers/chatController.ts';

const router = Router();

router.post('/chat', handleChat);

// Health check
router.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

export default router;
